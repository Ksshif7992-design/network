
import React, { useState, useEffect } from 'react';
import { ImageIcon, Layout, Plus, Search, Copy, Download, ExternalLink, Globe, FileText } from 'lucide-react';
import Card from './Shared/Card';
import { MOCK_CREATIVES } from '../constants';

interface CreativeAssetsProps {
  initialTab?: string;
}

const CreativeAssets: React.FC<CreativeAssetsProps> = ({ initialTab }) => {
  const normalizeTab = (tab?: string) => {
    if (!tab) return 'banners';
    const n = tab.toLowerCase().replace(/\s/g, '');
    if (n === 'banners') return 'banners';
    if (n === 'landers') return 'landing';
    if (n === 'prelanders') return 'prelanders';
    return 'banners';
  };

  const [activeTab, setActiveTab] = useState(normalizeTab(initialTab));

  useEffect(() => {
    if (initialTab) {
      setActiveTab(normalizeTab(initialTab));
    }
  }, [initialTab]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-black uppercase tracking-tight text-gray-100">Asset Cloud</h1>
          <p className="text-sm text-gray-500 font-medium">Host and distribute banners, landing pages, and email kits.</p>
        </div>
        <button className="bg-blue-600 hover:bg-blue-500 px-6 py-2 rounded-lg flex items-center gap-2 text-sm font-black uppercase tracking-widest transition-all shadow-lg shadow-blue-600/20 active:scale-95">
          <Plus size={18} /> Upload Assets
        </button>
      </div>

      <div className="flex gap-4 border-b border-gray-800 overflow-x-auto no-scrollbar">
        {[
          { id: 'banners', label: 'Banners', icon: <ImageIcon size={16}/> },
          { id: 'landing', label: 'Landers', icon: <Globe size={16}/> },
          { id: 'prelanders', label: 'Prelanders', icon: <Layout size={16}/> },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-6 py-4 text-xs font-black uppercase tracking-widest flex items-center gap-2 border-b-2 transition-all whitespace-nowrap ${
              activeTab === tab.id ? 'border-blue-500 text-blue-400 bg-blue-500/5' : 'border-transparent text-gray-500 hover:text-gray-300'
            }`}
          >
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      <div className="animate-in fade-in slide-in-from-bottom-2 duration-500 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
         {activeTab === 'prelanders' ? (
           <Card title="Bridge Pages" className="lg:col-span-2">
              <div className="p-12 text-center">
                 <div className="w-16 h-16 bg-gray-900 border border-gray-700 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-500">
                    <FileText size={32} />
                 </div>
                 <h3 className="text-lg font-black text-gray-100 uppercase tracking-tight">No Prelanders Hosted</h3>
                 <p className="text-xs text-gray-500 mt-2 font-medium">Pre-landing bridge pages increase conversion rates by priming traffic. Upload your first HTML/JS kit here.</p>
              </div>
           </Card>
         ) : (
           MOCK_CREATIVES.filter(c => activeTab === 'banners' ? c.type === 'banner' : c.type === 'landing').map(crt => (
             <Card key={crt.id} className="group overflow-hidden border-gray-700/50 hover:border-blue-500/30 transition-all p-0 shadow-none hover:shadow-xl">
                <div className="aspect-video relative overflow-hidden bg-gray-900 flex items-center justify-center">
                   <img src={crt.previewUrl} alt={crt.title} className="max-h-full transition-transform duration-500 group-hover:scale-105" />
                   <div className="absolute inset-0 bg-gray-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                      <button className="p-3 bg-white text-blue-600 rounded-full shadow-lg active:scale-95 transition-transform"><Download size={20}/></button>
                      <button className="p-3 bg-white text-gray-900 rounded-full shadow-lg active:scale-95 transition-transform"><ExternalLink size={20}/></button>
                   </div>
                </div>
                <div className="p-5 bg-gray-800/50">
                   <div className="flex justify-between items-start mb-2">
                      <span className="text-[9px] text-gray-600 font-mono tracking-tighter uppercase font-black">{crt.id}</span>
                      {crt.size && <span className="text-[9px] px-2 py-0.5 bg-gray-900 text-gray-500 rounded font-black uppercase tracking-widest">{crt.size}</span>}
                   </div>
                   <h3 className="font-black text-sm text-gray-100 mb-4 line-clamp-1 uppercase tracking-tight">{crt.title}</h3>
                   <button className="w-full py-2 bg-gray-900 border border-gray-700 rounded-xl text-[10px] font-black uppercase tracking-widest text-gray-500 hover:text-white hover:bg-gray-800 transition-all flex items-center justify-center gap-2">
                      <Copy size={12}/> Copy Implementation Code
                   </button>
                </div>
             </Card>
           ))
         )}
         
         <button className="border-2 border-dashed border-gray-800 rounded-2xl p-10 flex flex-col items-center justify-center text-gray-700 hover:text-gray-400 hover:border-blue-500/40 transition-all bg-gray-900/10 group">
            <div className="w-12 h-12 rounded-xl bg-gray-900 border border-gray-800 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform"><Plus size={24}/></div>
            <span className="text-[10px] font-black uppercase tracking-widest">Add New {activeTab.slice(0, -1)} Asset</span>
         </button>
      </div>
    </div>
  );
};

export default CreativeAssets;
