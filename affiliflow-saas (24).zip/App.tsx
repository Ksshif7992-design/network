
import React, { useState } from 'react';
import { PageId, ReportView } from './types';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Affiliates from './components/Affiliates';
import Advertisers from './components/Advertisers';
import Employees from './components/Employees';
import Offers from './components/Offers';
import FraudDetection from './components/FraudDetection';
import Campaigns from './components/Campaigns';
import Reports from './components/Reports';
import Conversions from './components/Conversions';
import Finance from './components/Finance';
import Postbacks from './components/Postbacks';
import APIIntegration from './components/APIIntegration';
import Settings from './components/Settings';
import Compliance from './components/Compliance';
import CreativeAssets from './components/CreativeAssets';
import Automation from './components/Automation';
import Communication from './components/Communication';
import Resources from './components/Resources';
import Tenants from './components/Tenants';

const App: React.FC = () => {
  const [activePage, setActivePage] = useState<PageId>('dashboard');
  const [activeSubPage, setActiveSubPage] = useState<string | undefined>(undefined);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  const handlePageChange = (id: PageId, subItem?: string) => {
    setActivePage(id);
    setActiveSubPage(subItem);
  };

  const renderContent = () => {
    switch (activePage) {
      case 'dashboard': return <Dashboard />;
      case 'tenants': return <Tenants />;
      case 'affiliates': return <Affiliates initialTab={activeSubPage} />;
      case 'advertisers': return <Advertisers initialTab={activeSubPage} />;
      case 'employees': return <Employees initialTab={activeSubPage} />;
      case 'offers': return <Offers initialTab={activeSubPage} />;
      case 'fraud': return <FraudDetection initialTab={activeSubPage} />;
      case 'campaigns': return <Campaigns initialTab={activeSubPage} />;
      case 'reports': 
        return <Reports initialTab={activeSubPage as any} />;
      case 'conversions': return <Conversions />;
      case 'finance': return <Finance initialTab={activeSubPage} />;
      case 'postbacks': return <Postbacks />;
      case 'api': return <APIIntegration />;
      case 'compliance': return <Compliance initialTab={activeSubPage} />;
      case 'creatives': return <CreativeAssets initialTab={activeSubPage} />;
      case 'automation': return <Automation initialTab={activeSubPage} />;
      case 'communication': return <Communication initialTab={activeSubPage} />;
      case 'resources': return <Resources initialTab={activeSubPage} />;
      case 'settings': return <Settings initialTab={activeSubPage} />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-900 overflow-hidden font-sans antialiased text-gray-100">
      <Sidebar 
        activePage={activePage} 
        activeSubPage={activeSubPage}
        onPageChange={handlePageChange} 
        collapsed={sidebarCollapsed}
        setCollapsed={setSidebarCollapsed}
      />
      
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header 
          toggleSidebar={() => setSidebarCollapsed(!sidebarCollapsed)} 
          currentPage={activePage}
        />
        
        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          <div className="max-w-7xl mx-auto">
            {renderContent()}
          </div>
        </main>
      </div>
    </div>
  );
};

export default App;
