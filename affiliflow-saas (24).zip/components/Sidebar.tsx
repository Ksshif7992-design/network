
import React, { useState } from 'react';
import { ChevronDown, ChevronRight, Zap, Search } from 'lucide-react';
import { SIDEBAR_NAV } from '../constants';
import { PageId } from '../types';

interface SidebarProps {
  activePage: PageId;
  activeSubPage?: string;
  onPageChange: (id: PageId, subItem?: string) => void;
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activePage, activeSubPage, onPageChange, collapsed, setCollapsed }) => {
  // Track which menus are open. Default to the current active page's menu being open.
  const [expandedMenus, setExpandedMenus] = useState<Record<string, boolean>>({
    [activePage]: true,
    reports: true
  });

  const toggleSubMenu = (id: string) => {
    setExpandedMenus(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  return (
    <aside className={`bg-gray-950 border-r border-gray-800 transition-all duration-300 flex flex-col h-screen z-[200] ${collapsed ? 'w-20' : 'w-64'}`}>
      {/* BRANDING */}
      <div className="p-6 flex items-center gap-3 shrink-0">
        <div 
          className="bg-blue-600 p-2 rounded-xl cursor-pointer shadow-lg shadow-blue-600/20 active:scale-95 transition-all" 
          onClick={() => onPageChange('dashboard')}
        >
          <Zap size={22} className="text-white" fill="white" />
        </div>
        {!collapsed && (
          <div className="flex flex-col">
            <span className="font-black text-lg tracking-tighter text-white uppercase italic leading-none">AffiliFlow</span>
            <span className="text-[8px] font-black text-blue-500 uppercase tracking-[0.2em] mt-1">Enterprise Core</span>
          </div>
        )}
      </div>

      {/* QUICK SEARCH (Only when not collapsed) */}
      {!collapsed && (
        <div className="px-4 mb-4">
          <div className="relative group">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-600 group-focus-within:text-blue-500 transition-colors" size={14} />
            <input 
              type="text" 
              placeholder="Navigate..." 
              className="w-full bg-gray-900/50 border border-gray-800 rounded-xl pl-9 pr-4 py-2 text-[10px] font-bold text-gray-400 focus:outline-none focus:ring-1 focus:ring-blue-500 transition-all"
            />
          </div>
        </div>
      )}

      {/* NAVIGATION */}
      <nav className="flex-1 overflow-y-auto no-scrollbar px-3 py-2 space-y-1">
        {SIDEBAR_NAV.map((item) => {
          const isActive = activePage === item.id;
          const hasSub = item.subItems.length > 0;
          const isExpanded = expandedMenus[item.id];

          return (
            <div key={item.id} className="space-y-1">
              <button
                onClick={() => {
                  if (hasSub && !collapsed) {
                    toggleSubMenu(item.id);
                  }
                  onPageChange(item.id);
                }}
                className={`w-full flex items-center px-3 py-2.5 rounded-xl transition-all group relative ${
                  isActive 
                    ? 'bg-blue-600 text-white shadow-xl shadow-blue-600/10' 
                    : 'text-gray-500 hover:bg-gray-900 hover:text-gray-200'
                }`}
              >
                <span className={`${isActive ? 'text-white' : 'text-gray-500 group-hover:text-blue-400 transition-colors'}`}>
                  {item.icon}
                </span>
                
                {!collapsed && (
                  <div className="ml-3 flex-1 flex justify-between items-center overflow-hidden">
                    <span className="font-black text-[11px] uppercase tracking-widest truncate">{item.label}</span>
                    {hasSub && (
                      <span className={`transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`}>
                        <ChevronDown size={14} className={isActive ? 'text-white/50' : 'text-gray-700'} />
                      </span>
                    )}
                  </div>
                )}

                {collapsed && isActive && (
                  <div className="absolute left-0 w-1 h-6 bg-white rounded-r-full"></div>
                )}
              </button>

              {/* SUBMENU ITEMS */}
              {!collapsed && hasSub && isExpanded && (
                <div className="ml-4 pl-5 border-l border-gray-800/50 space-y-1 animate-in slide-in-from-top-2 duration-200">
                  {item.subItems.map(sub => {
                    const normalizedSub = sub.toLowerCase().replace(/\s/g, '');
                    const isSubActive = isActive && activeSubPage?.toLowerCase().replace(/\s/g, '') === normalizedSub;

                    return (
                      <button
                        key={sub}
                        onClick={(e) => {
                          e.stopPropagation();
                          onPageChange(item.id, sub);
                        }}
                        className={`w-full text-left px-3 py-2 text-[10px] font-black uppercase tracking-[0.1em] transition-all rounded-lg relative ${
                          isSubActive 
                            ? 'text-blue-400 bg-blue-400/5' 
                            : 'text-gray-600 hover:text-gray-300 hover:translate-x-1'
                        }`}
                      >
                        {isSubActive && <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-1 bg-blue-500 rounded-full"></div>}
                        {sub}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* FOOTER USER PROFILE */}
      <div className="p-4 border-t border-gray-800/50 shrink-0">
        {!collapsed ? (
          <div className="flex items-center bg-gray-900/50 rounded-2xl p-3 border border-gray-800/50 hover:border-gray-700 transition-all cursor-pointer group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-xs font-black text-white shadow-lg shadow-blue-600/20 group-hover:scale-105 transition-all">
              JD
            </div>
            <div className="ml-3 overflow-hidden">
              <p className="text-[11px] font-black text-gray-100 uppercase tracking-tight truncate">John Doe</p>
              <p className="text-[9px] font-black text-gray-600 uppercase tracking-widest truncate">Master Node</p>
            </div>
          </div>
        ) : (
          <div className="flex justify-center">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-xs font-black text-white shadow-lg shadow-blue-600/20">
              JD
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};

export default Sidebar;
