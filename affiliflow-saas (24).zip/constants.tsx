
import React from 'react';
import { 
  LayoutDashboard, 
  BarChart3, 
  Users, 
  Briefcase,
  UserCog,
  Tag, 
  Zap, 
  RotateCw, 
  Link2, 
  CreditCard, 
  ShieldAlert, 
  PieChart, 
  Webhook, 
  Key, 
  Settings,
  FileCheck,
  Image as ImageIcon,
  Cpu,
  ChevronRight,
  MessageSquare,
  BookOpen,
  Activity,
  Layers,
  Network,
  Share2
} from 'lucide-react';
import { PageId, Stat, Affiliate, Offer, Advertiser, Tenant } from './types';

export const SIDEBAR_NAV = [
  { id: 'dashboard' as PageId, icon: <LayoutDashboard size={20} />, label: 'Dashboard', subItems: [] },
  { id: 'tenants' as PageId, icon: <Network size={20} />, label: 'Platform Tenants', subItems: ['Instances', 'Packages', 'Domains'] },
  { 
    id: 'reports' as PageId, 
    icon: <BarChart3 size={20} />, 
    label: 'Reports', 
    subItems: [
      'Performance', 
      'Conversions', 
      'Advertiser', 
      'Affiliate', 
      'Real-time', 
      'Custom Builder', 
      'Scheduled', 
      'Geographic', 
      'Device'
    ] 
  },
  { id: 'affiliates' as PageId, icon: <Users size={20} />, label: 'Affiliates', subItems: ['Directory', 'Approvals', 'Referral Program', 'Tiers', 'Payouts'] },
  { id: 'advertisers' as PageId, icon: <Briefcase size={20} />, label: 'Advertisers', subItems: ['Directory', 'Approvals', 'Billing', 'IO Manager'] },
  { id: 'offers' as PageId, icon: <Tag size={20} />, label: 'Offers', subItems: ['Marketplace', 'Approval Queue', 'Visibility Rules', 'Caps & Goals'] },
  { id: 'campaigns' as PageId, icon: <Zap size={20} />, label: 'Campaigns', subItems: ['Tracking Links', 'SmartLinks', 'Rotations'] },
  { id: 'communication' as PageId, icon: <MessageSquare size={20} />, label: 'Communication', subItems: ['Announcements', 'Support Tickets', 'Email Center'] },
  { id: 'resources' as PageId, icon: <BookOpen size={20} />, label: 'Resources', subItems: ['Library', 'Tutorials', 'API Docs'] },
  { id: 'conversions' as PageId, icon: <Activity size={20} />, label: 'Clicks & Events', subItems: [] },
  { id: 'postbacks' as PageId, icon: <Share2 size={20} />, label: 'Postbacks', subItems: ['Relay Flow', 'Parameter Mapping', 'Partner Config', 'Signal History'] },
  { id: 'creatives' as PageId, icon: <ImageIcon size={20} />, label: 'Creatives', subItems: ['Banners', 'Landers', 'Prelanders'] },
  { id: 'finance' as PageId, icon: <CreditCard size={20} />, label: 'Finance', subItems: ['Wallet', 'Payout History', 'Commission Rules'] },
  { id: 'automation' as PageId, icon: <Cpu size={20} />, label: 'Automation', subItems: ['Smart Rules', 'Webhooks', 'Alerts'] },
  { id: 'fraud' as PageId, icon: <ShieldAlert size={20} />, label: 'Fraud Detection', subItems: ['Scoreboard', 'Click Validation'] },
  { id: 'compliance' as PageId, icon: <FileCheck size={20} />, label: 'Compliance', subItems: ['KYC/Docs', 'Tax Forms', 'GDPR'] },
  { id: 'employees' as PageId, icon: <UserCog size={20} />, label: 'Internal Staff', subItems: ['Directory', 'Audit Trail', 'Roles'] },
  { id: 'settings' as PageId, icon: <Settings size={20} />, label: 'Settings', subItems: ['Account', 'Security', 'White Label'] },
];

export const MOCK_TENANTS: Tenant[] = [
  { id: 'TEN-001', adminName: 'Global Ad Group', domain: 'track.globalsolvers.io', package: 'Enterprise', status: 'active', created: '2023-01-10', revenue: '$1.4M' },
  { id: 'TEN-002', adminName: 'Growth Alpha', domain: 'g.alpha-media.com', package: 'Scale', status: 'active', created: '2023-05-15', revenue: '$450k' },
  { id: 'TEN-003', adminName: 'Pure Performance', domain: 'tracking.pure.net', package: 'Core', status: 'pending', created: '2024-02-01', revenue: '$0' },
];

export const MOCK_STATS: Stat[] = [
  { label: 'Network Revenue', value: '$128,430', change: 12.5, trend: 'up' },
  { label: 'Payout to Affs', value: '$92,104', change: 8.2, trend: 'up' },
  { label: 'Net Profit', value: '$36,326', change: 14.2, trend: 'up', isProfit: true },
  { label: 'Avg Margin', value: '28.3%', change: 2.1, trend: 'up' },
  { label: 'Network EPC', value: '$1.84', change: 4.3, trend: 'up' },
  { label: 'Postback Success', value: '99.9%', change: 0.1, trend: 'up' },
];

export const MOCK_CHART_DATA = [
  { name: '08:00', revenue: 4000, profit: 1200, conversions: 240, prevRevenue: 3800 },
  { name: '10:00', revenue: 3000, profit: 900, conversions: 180, prevRevenue: 4200 },
  { name: '12:00', revenue: 6500, profit: 2100, conversions: 420, prevRevenue: 5100 },
  { name: '14:00', revenue: 8000, profit: 2400, conversions: 510, prevRevenue: 7200 },
  { name: '16:00', revenue: 7200, profit: 1900, conversions: 480, prevRevenue: 6800 },
  { name: '18:00', revenue: 9500, profit: 3100, conversions: 610, prevRevenue: 8900 },
  { name: '20:00', revenue: 11000, profit: 3800, conversions: 720, prevRevenue: 10500 },
];

export const MOCK_CHANNEL_DATA = [
  { name: 'Search', value: 40, color: '#3b82f6' },
  { name: 'Social', value: 30, color: '#10b981' },
  { name: 'Native', value: 20, color: '#8b5cf6' },
  { name: 'Email', value: 10, color: '#f59e0b' },
];

export const MOCK_ADVERTISERS: Advertiser[] = [
  { 
    id: 'ADV-001', name: 'CyberShield Global', status: 'active', offers: 12, spend: '$85,200', balance: '$4,200', manager: 'John Doe',
    contact: { name: 'Mark Spencer', email: 'mark@cybershield.com', phone: '+1 555-0123' }
  },
  { 
    id: 'ADV-002', name: 'Fintech Flow', status: 'active', offers: 4, spend: '$42,000', balance: '$12,500', manager: 'Alex Kim',
    contact: { name: 'Sarah Miller', email: 'sarah@fintechflow.io', phone: '+1 555-0199' }
  },
  { 
    id: 'ADV-003', name: 'NutraGains Group', status: 'onboarding', offers: 0, spend: '$0', balance: '$0', manager: 'John Doe',
    contact: { name: 'Alex Johnson', email: 'alex@nutragains.com', phone: '+1 555-0777' }
  }
];

export const MOCK_OFFERS: Offer[] = [
  { id: 'OFF-101', title: 'VPN Master Pro - WW', category: 'Software', payout: '$15.00 CPA', status: 'active', geo: ['US', 'UK'], conversionRate: '4.2%', visibility: 'Public', caps: { daily: 500, resetAt: '00:00 UTC' } },
  { id: 'OFF-102', title: 'Crypto Wallet 2024', category: 'Finance', payout: '$120.00 CPL', status: 'active', geo: ['DE', 'IT'], conversionRate: '1.8%', visibility: 'Permission Required', caps: { daily: 100, resetAt: '00:00 UTC' } },
  { id: 'OFF-103', title: 'Game Strike: Mobile', category: 'Gaming', payout: '$2.50 CPI', status: 'active', geo: ['US', 'CA'], conversionRate: '12.1%', visibility: 'Public', caps: { daily: 2000, resetAt: '00:00 UTC' } },
];

export const MOCK_AFFILIATES: Affiliate[] = [
  { id: 'AFF-001', name: 'Elite Performance', status: 'active', manager: 'John Doe', conversions: 1240, payout: '$15,400', revenue: '$18,200', tier: 'Platinum', billingSchedule: 'Weekly' },
  { id: 'AFF-002', name: 'Social Pulse', status: 'active', manager: 'Jane Smith', conversions: 850, payout: '$8,200', revenue: '$10,500', tier: 'Gold', billingSchedule: 'Bi-Weekly' },
  { id: 'AFF-003', name: 'Growth Media', status: 'pending', manager: 'Alex Kim', conversions: 0, payout: '$0', revenue: '$0', tier: 'Silver', billingSchedule: 'Monthly' },
];

export const MOCK_MANAGERS = [
  { name: 'John Doe', portfolio: '$450k', growth: '+12%', type: 'AM' },
  { name: 'Jane Smith', portfolio: '$320k', growth: '+8%', type: 'AM' },
  { name: 'Alex Kim', portfolio: '$180k', growth: '+25%', type: 'Sales' },
];

export const MOCK_FRAUD_ALERTS = [
  { id: 'FR-001', reason: 'Bot Traffic Pattern', source: 'AFF-002', timestamp: '10m ago', score: 94 },
  { id: 'FR-002', reason: 'Geo Mismatch', source: 'AFF-005', timestamp: '24m ago', score: 82 },
  { id: 'FR-003', reason: 'Duplicate IP Conversions', source: 'AFF-012', timestamp: '1h ago', score: 91 },
];

export const MOCK_CREATIVES = [
  { id: 'CRT-001', title: 'VPN Summer Promo 728x90', type: 'banner', previewUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?w=400&h=100&fit=crop', size: '728x90' },
  { id: 'CRT-002', title: 'Crypto Wallet Dark Theme 300x250', type: 'banner', previewUrl: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?w=300&h=250&fit=crop', size: '300x250' },
  { id: 'CRT-003', title: 'Modern Landing Page v1', type: 'landing', previewUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop' },
];
